import json

def lambda_handler(event, context):
  # Get the input data
  data = json.loads(event['body'])

  # Do something with the input data
  # For example, you could print the data to the console
  print(data)

  # Return a response
  return {
    'statusCode': 200,
    'body': json.dumps({'message': 'Hello, World!'})
  }